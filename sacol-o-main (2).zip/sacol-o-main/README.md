# O sacolão do sacão foi criado pro Gregory e Maicon, com intuito de vender as melhores frutas do mercado frutifero
